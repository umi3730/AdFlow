package application

import (
	"sync"

	"github.com/umi3730/adflow/internal/decision/domain"
)

// resultPool reduces GC pressure by reusing Result objects
var resultPool = sync.Pool{
	New: func() interface{} {
		return &domain.Result{}
	},
}

// getResult obtains a Result from the pool
func getResult() *domain.Result {
	return resultPool.Get().(*domain.Result)
}

// putResult returns a Result to the pool after clearing it
func putResult(r *domain.Result) {
	// Clear all fields to avoid memory leaks
	*r = domain.Result{}
	resultPool.Put(r)
}

// requestPool reduces allocations for normalized request data
var requestPool = sync.Pool{
	New: func() interface{} {
		return &domain.Request{}
	},
}

// getRequest obtains a Request from the pool
func getRequest() *domain.Request {
	return requestPool.Get().(*domain.Request)
}

// putRequest returns a Request to the pool after clearing it
func putRequest(r *domain.Request) {
	*r = domain.Request{}
	requestPool.Put(r)
}

// candidateSlicePool reduces allocations for candidate filtering
var candidateSlicePool = sync.Pool{
	New: func() interface{} {
		s := make([]domain.Candidate, 0, 32)
		return &s
	},
}

// getCandidateSlice obtains a candidate slice from the pool
func getCandidateSlice() *[]domain.Candidate {
	return candidateSlicePool.Get().(*[]domain.Candidate)
}

// putCandidateSlice returns a candidate slice to the pool
func putCandidateSlice(s *[]domain.Candidate) {
	*s = (*s)[:0] // Reset length but keep capacity
	candidateSlicePool.Put(s)
}
