package domain

import "errors"

var (
	ErrBackpressure            = errors.New("asynchronous processing backlog is at capacity")
	ErrBackpressureUnavailable = errors.New("asynchronous processing backlog observation is unavailable")
	ErrRequestConflict         = errors.New("request ID is already bound to different parameters")
	ErrDecisionInProgress      = errors.New("decision is already being executed")
	ErrDecisionExecutionLost   = errors.New("decision execution ownership expired or changed")
	ErrDecisionNotCommitted    = errors.New("decision transaction definitely did not commit")
	ErrInvalidRequest          = errors.New("decision request is invalid")
	ErrProfileNotFound         = errors.New("user profile not found")
	ErrRateLimited             = errors.New("decision request rate limited")
	ErrOverloaded              = errors.New("decision service overloaded")
	ErrDecisionTimeout         = errors.New("decision request timed out")
	ErrAdmissionUnavailable    = errors.New("decision admission control unavailable")
)
