package database

import (
	"context"
	"database/sql"
	"errors"
	"time"

	mysqldriver "github.com/go-sql-driver/mysql"
)

// PoolConfig holds database connection pool configuration
type PoolConfig struct {
	MaxOpenConns    int
	MaxIdleConns    int
	ConnMaxLifetime time.Duration
	ConnMaxIdleTime time.Duration
}

// DefaultPoolConfig retains the previously verified limits; tune with a workload
// comparison rather than treating a larger connection limit as higher throughput.
func DefaultPoolConfig() PoolConfig {
	return PoolConfig{
		MaxOpenConns:    30,
		MaxIdleConns:    10,
		ConnMaxLifetime: 3 * time.Minute,
		ConnMaxIdleTime: time.Minute,
	}
}

func OpenMySQL(dsn string) (*sql.DB, error) {
	return OpenMySQLWithConfig(dsn, DefaultPoolConfig())
}

func OpenMySQLWithConfig(dsn string, poolCfg PoolConfig) (*sql.DB, error) {
	if poolCfg.MaxOpenConns <= 0 || poolCfg.MaxIdleConns < 0 || poolCfg.MaxIdleConns > poolCfg.MaxOpenConns || poolCfg.ConnMaxLifetime < 0 || poolCfg.ConnMaxIdleTime < 0 {
		return nil, errors.New("invalid database pool configuration")
	}
	// DATETIME values, SQL defaults and UTC lease comparisons must share one
	// clock representation. loc=UTC alone only controls driver conversion.
	cfg, err := mysqldriver.ParseDSN(dsn)
	if err != nil {
		return nil, err
	}
	cfg.Loc = time.UTC
	// These statements are executed through database/sql. Let the driver
	// encode parameters rather than preparing, executing and closing a server
	// statement on every call; this removes extra network round trips. The
	// driver retains its charset/SQL-mode-aware escaping and fallback rules.
	cfg.InterpolateParams = true
	if cfg.Params == nil {
		cfg.Params = make(map[string]string)
	}
	cfg.Params["time_zone"] = "'+00:00'"

	db, err := sql.Open("mysql", cfg.FormatDSN())
	if err != nil {
		return nil, err
	}

	// Apply the explicitly selected limits.
	db.SetMaxOpenConns(poolCfg.MaxOpenConns)
	db.SetMaxIdleConns(poolCfg.MaxIdleConns)
	db.SetConnMaxLifetime(poolCfg.ConnMaxLifetime)
	db.SetConnMaxIdleTime(poolCfg.ConnMaxIdleTime)

	return db, nil
}

// StatsMonitor periodically records connection pool statistics to metrics
type StatsMonitor struct {
	db       *sql.DB
	recorder StatsRecorder
	interval time.Duration
}

// StatsRecorder is the interface for recording pool metrics
type StatsRecorder interface {
	RecordDBPoolStats(maxOpen, open, inUse, idle, waitCount int, waitDuration time.Duration)
}

// NewStatsMonitor creates a connection pool statistics monitor
func NewStatsMonitor(db *sql.DB, recorder StatsRecorder, interval time.Duration) *StatsMonitor {
	return &StatsMonitor{
		db:       db,
		recorder: recorder,
		interval: interval,
	}
}

// Run starts monitoring connection pool statistics until context is canceled
func (m *StatsMonitor) Run(ctx context.Context) {
	ticker := time.NewTicker(m.interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			stats := m.db.Stats()
			m.recorder.RecordDBPoolStats(
				stats.MaxOpenConnections,
				stats.OpenConnections,
				stats.InUse,
				stats.Idle,
				int(stats.WaitCount),
				stats.WaitDuration,
			)
		}
	}
}
